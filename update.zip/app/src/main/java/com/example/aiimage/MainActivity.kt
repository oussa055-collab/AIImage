package com.example.aiimage

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.text.InputType
import android.util.Base64
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.roundToInt

class Keys(val cfId: String, val cfToken: String, val nvKey: String)
class HttpResult(val code: Int, val bytes: ByteArray)

class MainActivity : Activity() {

    companion object {
        const val PICK_CODE = 1
    }

    private lateinit var prefs: SharedPreferences
    private lateinit var cfIdBox: EditText
    private lateinit var cfTokenBox: EditText
    private lateinit var nvBox: EditText
    private lateinit var promptBox: EditText
    private lateinit var modeGroup: RadioGroup
    private lateinit var runBtn: Button
    private lateinit var saveBtn: Button
    private lateinit var status: TextView
    private lateinit var preview: ImageView
    private var inputBitmap: Bitmap? = null
    private var resultBitmap: Bitmap? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("cfg", MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(24))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        cfIdBox = EditText(this).apply {
            hint = "Cloudflare Account ID (اختياري)"
            setText(prefs.getString("cf_id", ""))
            setSingleLine()
        }
        cfTokenBox = EditText(this).apply {
            hint = "Cloudflare API Token (اختياري)"
            setText(prefs.getString("cf_token", ""))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine()
        }
        nvBox = EditText(this).apply {
            hint = "NVIDIA API Key (اختياري)"
            setText(prefs.getString("nv_key", ""))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine()
        }

        modeGroup = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        listOf(
            1 to "توليد صورة من فكرة (مجاني، يبدّل بين 4 سيرفرات)",
            2 to "تحسين صورة: ضوء، ألوان، وضوح (مجاني، في التليفون)",
            3 to "إعادة رسم الصورة بالأمر (مجاني، بطيء، تجريبي)"
        ).forEach { (id, label) ->
            modeGroup.addView(RadioButton(this).apply { this.id = id; text = label })
        }
        modeGroup.check(1)

        promptBox = EditText(this).apply {
            hint = "اكتب الفكرة أو الأمر هنا (بالإنجليزية أحسن)"
            minLines = 2
        }

        val pickBtn = Button(this).apply {
            text = "اختار تصويرة من المعرض"
            setOnClickListener {
                val i = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }
                startActivityForResult(i, PICK_CODE)
            }
        }
        runBtn = Button(this).apply { text = "ابدا"; setOnClickListener { run() } }
        saveBtn = Button(this).apply {
            text = "احفظ في المعرض"
            isEnabled = false
            setOnClickListener { save() }
        }
        status = TextView(this).apply { setPadding(0, dp(8), 0, dp(8)) }
        preview = ImageView(this).apply {
            adjustViewBounds = true
            maxHeight = dp(450)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }

        listOf(cfIdBox, cfTokenBox, nvBox, modeGroup, promptBox, pickBtn, runBtn, status, preview, saveBtn)
            .forEach {
                root.addView(it, LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_CODE && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            val bmp = loadBitmap(uri)
            if (bmp == null) { setStatus("ما نجمتش نقرا الصورة"); return }
            inputBitmap = bmp
            preview.setImageBitmap(bmp)
            setStatus("الصورة جاهزة")
        }
    }

    private fun loadBitmap(uri: Uri, maxSide: Int = 1536): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > maxSide) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
    }

    private fun setStatus(s: String) { status.text = s }
    private fun setStatusAsync(s: String) { runOnUiThread { setStatus(s) } }

    private fun runAsync(work: () -> Bitmap) {
        runBtn.isEnabled = false
        saveBtn.isEnabled = false
        setStatus("نخدم... (ممكن ياخذ وقت)")
        thread {
            try {
                val bmp = work()
                runOnUiThread {
                    resultBitmap = bmp
                    preview.setImageBitmap(bmp)
                    saveBtn.isEnabled = true
                    setStatus("خلصت ✅")
                }
            } catch (e: Throwable) {
                setStatusAsync("خطأ: ${e.message}")
            } finally {
                runOnUiThread { runBtn.isEnabled = true }
            }
        }
    }

    private fun run() {
        val keys = Keys(
            cfIdBox.text.toString().trim(),
            cfTokenBox.text.toString().trim(),
            nvBox.text.toString().trim()
        )
        prefs.edit()
            .putString("cf_id", keys.cfId)
            .putString("cf_token", keys.cfToken)
            .putString("nv_key", keys.nvKey)
            .apply()

        val mode = modeGroup.checkedRadioButtonId
        val prompt = promptBox.text.toString().trim()
        val img = inputBitmap

        when (mode) {
            1 -> {
                if (prompt.isEmpty()) { setStatus("اكتب الفكرة (بالإنجليزية أحسن)"); return }
                runAsync { generateChain(prompt, keys) }
            }
            2 -> {
                if (img == null) { setStatus("اختار تصويرة أولا"); return }
                runAsync { Enhancer.enhance(img) }
            }
            else -> {
                if (img == null) { setStatus("اختار تصويرة أولا"); return }
                if (prompt.isEmpty()) { setStatus("اكتب شنو تحب تولي عليه الصورة"); return }
                runAsync { callHorde(prompt, img, 0.55) }
            }
        }
    }

    // ---------- شبكة ----------

    private fun http(
        method: String, url: String, headers: Map<String, String>,
        body: ByteArray?, readTimeout: Int = 120000
    ): HttpResult {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = method
            conn.connectTimeout = 30000
            conn.readTimeout = readTimeout
            for ((k, v) in headers) conn.setRequestProperty(k, v)
            if (body != null) {
                conn.doOutput = true
                conn.outputStream.use { it.write(body) }
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val bytes = stream?.use { it.readBytes() } ?: ByteArray(0)
            return HttpResult(code, bytes)
        } finally {
            conn.disconnect()
        }
    }

    private fun decodeBitmap(bytes: ByteArray): Bitmap =
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: throw Exception("الرد مش صورة")

    private fun findBase64(o: Any?): String? {
        when (o) {
            is JSONObject -> for (k in o.keys()) {
                val r = findBase64(o.opt(k))
                if (r != null) return r
            }
            is JSONArray -> for (i in 0 until o.length()) {
                val r = findBase64(o.opt(i))
                if (r != null) return r
            }
            is String -> if (o.length > 1000 && !o.startsWith("http")) return o
        }
        return null
    }

    private fun imageFromResponse(bytes: ByteArray): Bitmap {
        if (bytes.size > 4 &&
            (bytes[0] == 0x89.toByte() ||
                (bytes[0] == 0xFF.toByte() && bytes[1] == 0xD8.toByte()) ||
                bytes[0] == 'R'.code.toByte())
        ) return decodeBitmap(bytes)
        val text = String(bytes, Charsets.UTF_8)
        val b64 = findBase64(JSONObject(text))
            ?: throw Exception("ما لقيتش صورة في الرد: ${text.take(150)}")
        return decodeBitmap(Base64.decode(b64, Base64.DEFAULT))
    }

    // ---------- السيرفرات المجانية ----------

    private fun generateChain(prompt: String, k: Keys): Bitmap {
        val providers = ArrayList<Pair<String, () -> Bitmap>>()
        if (k.cfId.isNotEmpty() && k.cfToken.isNotEmpty())
            providers.add(Pair("Cloudflare", { callCloudflare(prompt, k) }))
        if (k.nvKey.isNotEmpty())
            providers.add(Pair("NVIDIA", { callNvidia(prompt, k) }))
        providers.add(Pair("Pollinations", { callPollinations(prompt) }))
        providers.add(Pair("AI Horde", { callHorde(prompt, null, 0.0) }))

        val errors = StringBuilder()
        for (pass in 1..3) {
            errors.setLength(0)
            for ((name, fn) in providers) {
                setStatusAsync("نجرّب $name... (دورة $pass/3)")
                try {
                    return fn()
                } catch (e: Exception) {
                    errors.append("$name: ${e.message?.take(120)}\n")
                }
            }
            if (pass < 3) {
                for (s in 20 downTo 1) {
                    setStatusAsync("كل السيرفرات مشغولة. نعاود بعد $s ثانية (دورة ${pass + 1}/3)")
                    Thread.sleep(1000)
                }
            }
        }
        throw Exception("كل السيرفرات فشلت:\n$errors")
    }

    private fun callCloudflare(prompt: String, k: Keys): Bitmap {
        val body = JSONObject().put("prompt", prompt).put("steps", 4).toString().toByteArray()
        val url = "https://api.cloudflare.com/client/v4/accounts/${k.cfId}/ai/run/@cf/black-forest-labs/flux-1-schnell"
        val r = http("POST", url,
            mapOf("Authorization" to "Bearer ${k.cfToken}", "Content-Type" to "application/json"), body)
        if (r.code !in 200..299) throw Exception("HTTP ${r.code}: ${String(r.bytes).take(150)}")
        return imageFromResponse(r.bytes)
    }

    private fun callNvidia(prompt: String, k: Keys): Bitmap {
        val body = JSONObject()
            .put("prompt", prompt).put("width", 1024).put("height", 1024)
            .put("seed", 0).put("steps", 4)
            .toString().toByteArray()
        val r = http("POST", "https://ai.api.nvidia.com/v1/genai/black-forest-labs/flux.1-schnell",
            mapOf(
                "Authorization" to "Bearer ${k.nvKey}",
                "Accept" to "application/json",
                "Content-Type" to "application/json"
            ), body)
        if (r.code !in 200..299) throw Exception("HTTP ${r.code}: ${String(r.bytes).take(150)}")
        return imageFromResponse(r.bytes)
    }

    private fun callPollinations(prompt: String): Bitmap {
        val enc = URLEncoder.encode(prompt, "UTF-8").replace("+", "%20")
        val seed = System.currentTimeMillis() % 100000
        val url = "https://image.pollinations.ai/prompt/$enc?width=1024&height=1024&model=flux&nologo=true&seed=$seed"
        for (attempt in 1..3) {
            val r = http("GET", url, mapOf("User-Agent" to "Mozilla/5.0"), null, 180000)
            if (r.code in 200..299) return imageFromResponse(r.bytes)
            if (r.code == 429 && attempt < 3) {
                for (s in 16 downTo 1) {
                    setStatusAsync("Pollinations مشغول. نعاود بعد $s ثانية")
                    Thread.sleep(1000)
                }
                continue
            }
            throw Exception("HTTP ${r.code}")
        }
        throw Exception("Pollinations مشغول")
    }

    private fun roundTo64(v: Float): Int = ((v / 64f).roundToInt().coerceAtLeast(1)) * 64

    private fun callHorde(prompt: String, src: Bitmap?, strength: Double): Bitmap {
        val base = "https://aihorde.net/api/v2/generate"
        val headers = mapOf(
            "apikey" to "0000000000",
            "Content-Type" to "application/json",
            "Client-Agent" to "aiimage:1.0:unknown"
        )
        var w = 512
        var h = 512
        var srcB64: String? = null
        if (src != null) {
            val scale = 512f / maxOf(src.width, src.height)
            w = roundTo64(src.width * scale)
            h = roundTo64(src.height * scale)
            val scaled = Bitmap.createScaledBitmap(src, w, h, true)
            val bos = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, 90, bos)
            srcB64 = Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
        }
        val params = JSONObject().put("width", w).put("height", h).put("steps", 25).put("n", 1)
        if (srcB64 != null) params.put("denoising_strength", strength)
        val req = JSONObject()
            .put("prompt", prompt).put("params", params)
            .put("nsfw", false).put("censor_nsfw", true).put("r2", true)
        if (srcB64 != null) req.put("source_image", srcB64).put("source_processing", "img2img")

        val sub = http("POST", "$base/async", headers, req.toString().toByteArray())
        if (sub.code !in 200..299) throw Exception("Horde HTTP ${sub.code}: ${String(sub.bytes).take(200)}")
        val id = JSONObject(String(sub.bytes)).getString("id")

        val start = System.currentTimeMillis()
        while (System.currentTimeMillis() - start < 20 * 60 * 1000) {
            Thread.sleep(5000)
            val c = http("GET", "$base/check/$id", headers, null)
            if (c.code !in 200..299) continue
            val j = JSONObject(String(c.bytes))
            if (j.optBoolean("faulted")) throw Exception("Horde: فشل الطلب")
            if (j.optBoolean("done")) {
                val st = http("GET", "$base/status/$id", headers, null)
                val gens = JSONObject(String(st.bytes)).getJSONArray("generations")
                if (gens.length() == 0) throw Exception("Horde: ما رجّعش صورة (يمكن الفلتر)")
                val img = gens.getJSONObject(0).getString("img")
                if (img.startsWith("http")) {
                    val d = http("GET", img, emptyMap(), null)
                    return imageFromResponse(d.bytes)
                }
                return imageFromResponse(Base64.decode(img, Base64.DEFAULT))
            }
            setStatusAsync(
                "AI Horde: في الطابور. الترتيب ${j.optInt("queue_position")} - الوقت المتوقع ${j.optInt("wait_time")} ثانية"
            )
        }
        http("DELETE", "$base/status/$id", headers, null)
        throw Exception("AI Horde: انتهى الوقت")
    }

    private fun save() {
        val bmp = resultBitmap ?: return
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "ai_${System.currentTimeMillis()}.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AIImage")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri == null) { setStatus("ما نجمتش نحفظ"); return }
        contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        setStatus("تحفظت في المعرض (Pictures/AIImage)")
    }
}

object Enhancer {

    fun enhance(src: Bitmap): Bitmap {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        autoLevels(px)
        saturate(px, 1.12f)
        val out = unsharp(px, w, h, 2, 0.7f)
        return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
    }

    private fun autoLevels(px: IntArray) {
        val hist = IntArray(256)
        for (p in px) {
            val l = (0.299 * ((p shr 16) and 255) + 0.587 * ((p shr 8) and 255) + 0.114 * (p and 255)).toInt()
            hist[l]++
        }
        val clip = px.size / 100
        var acc = 0
        var lo = 0
        while (lo < 255 && acc + hist[lo] <= clip) { acc += hist[lo]; lo++ }
        acc = 0
        var hi = 255
        while (hi > 0 && acc + hist[hi] <= clip) { acc += hist[hi]; hi-- }
        if (hi - lo < 50) return
        val scale = 255f / (hi - lo)
        var sum = 0L
        for (i in 0..255) sum += i.toLong() * hist[i]
        val mean = sum.toFloat() / px.size
        val gamma = if (mean < 110f) 0.85 else 1.0
        val lut = IntArray(256) { v ->
            val x = ((v - lo) * scale).coerceIn(0f, 255f) / 255f
            val y = Math.pow(x.toDouble(), gamma).toFloat()
            (y * 255f + 0.5f).toInt().coerceIn(0, 255)
        }
        for (i in px.indices) {
            val p = px[i]
            val r = lut[(p shr 16) and 255]
            val g = lut[(p shr 8) and 255]
            val b = lut[p and 255]
            px[i] = (p and (0xFF shl 24)) or (r shl 16) or (g shl 8) or b
        }
    }

    private fun saturate(px: IntArray, s: Float) {
        for (i in px.indices) {
            val p = px[i]
            val r = (p shr 16) and 255
            val g = (p shr 8) and 255
            val b = p and 255
            val l = 0.299f * r + 0.587f * g + 0.114f * b
            val nr = (l + (r - l) * s).toInt().coerceIn(0, 255)
            val ng = (l + (g - l) * s).toInt().coerceIn(0, 255)
            val nb = (l + (b - l) * s).toInt().coerceIn(0, 255)
            px[i] = (p and (0xFF shl 24)) or (nr shl 16) or (ng shl 8) or nb
        }
    }

    private fun unsharp(px: IntArray, w: Int, h: Int, radius: Int, amount: Float): IntArray {
        val out = IntArray(px.size) { 0xFF shl 24 }
        val chan = IntArray(px.size)
        val tmp = IntArray(px.size)
        val blur = IntArray(px.size)
        for (c in 0..2) {
            val shift = 16 - 8 * c
            for (i in px.indices) chan[i] = (px[i] shr shift) and 255
            boxBlur(chan, tmp, blur, w, h, radius)
            for (i in px.indices) {
                val o = chan[i]
                val diff = o - blur[i]
                val v = if (abs(diff) < 3) o else (o + amount * diff).toInt().coerceIn(0, 255)
                out[i] = out[i] or (v shl shift)
            }
        }
        return out
    }

    private fun boxBlur(src: IntArray, tmp: IntArray, dst: IntArray, w: Int, h: Int, r: Int) {
        val d = 2 * r + 1
        for (y in 0 until h) {
            val row = y * w
            var sum = 0
            for (x in -r..r) sum += src[row + x.coerceIn(0, w - 1)]
            for (x in 0 until w) {
                tmp[row + x] = sum / d
                val add = (x + r + 1).coerceAtMost(w - 1)
                val rem = (x - r).coerceAtLeast(0)
                sum += src[row + add] - src[row + rem]
            }
        }
        for (x in 0 until w) {
            var sum = 0
            for (y in -r..r) sum += tmp[y.coerceIn(0, h - 1) * w + x]
            for (y in 0 until h) {
                dst[y * w + x] = sum / d
                val add = (y + r + 1).coerceAtMost(h - 1)
                val rem = (y - r).coerceAtLeast(0)
                sum += tmp[add * w + x] - tmp[rem * w + x]
            }
        }
    }
}
