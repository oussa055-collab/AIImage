package com.example.aiimage

import ai.onnxruntime.OnnxJavaType
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.text.InputType
import android.util.Base64
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

class Keys(val cfId: String, val cfToken: String, val nvKey: String)
class HttpResult(val code: Int, val bytes: ByteArray)

class MainActivity : Activity() {

    companion object {
        const val PICK_CODE = 1
        const val PICK_MODEL = 2
        const val MAX_MODEL_BYTES = 1_610_612_736L // 1.5 GB
        val SIZES = listOf(512, 768, 1024)
        val SUGGESTED = listOf(
            Pair("RealESR_General_x4 (5 MB، سريع)",
                "https://huggingface.co/baker76/upscale-models/resolve/main/RealESR_General_x4.onnx"),
            Pair("RealESRGAN_x4plus (70 MB، أحسن جودة للصور)",
                "https://huggingface.co/baker76/upscale-models/resolve/main/RealESRGAN_x4plus.onnx"),
            Pair("UltraSharp_x4 (70 MB، حدّة عالية)",
                "https://huggingface.co/baker76/upscale-models/resolve/main/UltraSharp_x4.onnx"),
            Pair("RealESRGAN_anime_x4 (19 MB، رسوم وأنمي)",
                "https://huggingface.co/baker76/upscale-models/resolve/main/RealESRGAN_anime_x4.onnx")
        )
    }

    private lateinit var prefs: SharedPreferences
    private lateinit var cfIdBox: EditText
    private lateinit var cfTokenBox: EditText
    private lateinit var nvBox: EditText
    private lateinit var promptBox: EditText
    private lateinit var modeGroup: RadioGroup
    private lateinit var engineSpinner: Spinner
    private lateinit var sizeSpinner: Spinner
    private lateinit var runBtn: Button
    private lateinit var saveBtn: Button
    private lateinit var zoomBtn: Button
    private lateinit var status: TextView
    private lateinit var preview: ImageView
    private var inputBitmap: Bitmap? = null
    private var resultBitmap: Bitmap? = null
    private var lastOriginal: Bitmap? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("cfg", MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(24))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        cfIdBox = EditText(this).apply {
            hint = "Cloudflare Account ID (اختياري)"
            setText(prefs.getString("cf_id", ""))
            setSingleLine()
        }
        cfTokenBox = EditText(this).apply {
            hint = "Cloudflare API Token (اختياري)"
            setText(prefs.getString("cf_token", ""))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine()
        }
        nvBox = EditText(this).apply {
            hint = "NVIDIA API Key (اختياري)"
            setText(prefs.getString("nv_key", ""))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine()
        }

        modeGroup = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        listOf(
            1 to "توليد صورة من فكرة (مجاني، يبدّل بين 4 سيرفرات)",
            2 to "تحسين صورة (بالمحرك الي تختارو تحت)",
            3 to "إعادة رسم الصورة بالأمر (مجاني، بطيء، تجريبي)"
        ).forEach { (id, label) ->
            modeGroup.addView(RadioButton(this).apply { this.id = id; text = label })
        }
        modeGroup.check(1)

        val engineLabel = TextView(this).apply {
            text = "محرك التحسين (للوضع 2) والحجم الأقصى للصورة:"
            setPadding(0, dp(12), 0, 0)
        }
        engineSpinner = Spinner(this)
        sizeSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("512 (سريع)", "768", "1024 (بطيء)")
            )
            setSelection(prefs.getInt("size_idx", 0).coerceIn(0, 2))
        }

        val modelRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val suggestBtn = Button(this).apply {
            text = "موديلات مقترحة"; textSize = 12f
            setOnClickListener { showSuggested() }
        }
        val addBtn = Button(this).apply {
            text = "من التليفون"; textSize = 12f
            setOnClickListener { pickModelFile() }
        }
        val urlBtn = Button(this).apply {
            text = "من رابط"; textSize = 12f
            setOnClickListener { askModelUrl() }
        }
        val delBtn = Button(this).apply {
            text = "امسح"; textSize = 12f
            setOnClickListener { deleteSelectedModel() }
        }
        listOf(suggestBtn, addBtn, urlBtn, delBtn).forEach {
            modelRow.addView(it, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }

        promptBox = EditText(this).apply {
            hint = "اكتب الفكرة أو الأمر هنا (بالإنجليزية أحسن)"
            minLines = 2
        }

        val pickBtn = Button(this).apply {
            text = "اختار تصويرة من المعرض"
            setOnClickListener {
                val i = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }
                startActivityForResult(i, PICK_CODE)
            }
        }
        runBtn = Button(this).apply { text = "ابدا"; setOnClickListener { run() } }
        val cancelBtn = Button(this).apply {
            text = "إلغاء المعالجة"
            setOnClickListener { OnnxUpscaler.cancel = true; setStatus("نلغيو...") }
        }
        zoomBtn = Button(this).apply {
            text = "🔍 تكبير ومقارنة"
            isEnabled = false
            setOnClickListener { openViewer() }
        }
        saveBtn = Button(this).apply {
            text = "احفظ في المعرض"
            isEnabled = false
            setOnClickListener { save() }
        }
        status = TextView(this).apply { setPadding(0, dp(8), 0, dp(8)) }
        preview = ImageView(this).apply {
            adjustViewBounds = true
            maxHeight = dp(450)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setOnClickListener { openViewer() }
        }

        listOf(
            cfIdBox, cfTokenBox, nvBox, modeGroup, engineLabel, engineSpinner, sizeSpinner, modelRow,
            promptBox, pickBtn, runBtn, cancelBtn, status, preview, zoomBtn, saveBtn
        ).forEach {
            root.addView(it, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        setContentView(ScrollView(this).apply { addView(root) })
        refreshEngines(null)
    }

    // ---------- المحركات والموديلات ----------

    private fun modelsDir(): File = File(filesDir, "models").apply { mkdirs() }

    private fun listModels(): List<File> =
        (modelsDir().listFiles { f -> f.name.endsWith(".onnx", true) } ?: emptyArray())
            .sortedBy { it.name }

    private fun refreshEngines(selectName: String?) {
        val models = listModels()
        val names = ArrayList<String>()
        names.add("كلاسيكي (مدمج، سريع، بلا موديل)")
        models.forEach { names.add("AI: ${it.name} (${it.length() / 1_000_000} MB)") }
        engineSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        var idx = prefs.getInt("engine_idx", 0)
        if (selectName != null) {
            val k = models.indexOfFirst { it.name == selectName }
            if (k >= 0) idx = k + 1
        }
        engineSpinner.setSelection(if (idx in 0 until names.size) idx else 0)
    }

    private fun showSuggested() {
        val labels = SUGGESTED.map { it.first }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("اختار موديل (مجاني)")
            .setItems(labels) { _, which -> downloadModel(SUGGESTED[which].second) }
            .show()
    }

    private fun askModelUrl() {
        val box = EditText(this).apply { hint = "https://.../model.onnx"; setSingleLine() }
        AlertDialog.Builder(this)
            .setTitle("رابط موديل .onnx")
            .setView(box)
            .setPositiveButton("حمّل") { _, _ -> downloadModel(box.text.toString().trim()) }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun pickModelFile() {
        val i = Intent(Intent.ACTION_GET_CONTENT).apply { type = "*/*" }
        startActivityForResult(i, PICK_MODEL)
    }

    private fun deleteSelectedModel() {
        val pos = engineSpinner.selectedItemPosition
        val models = listModels()
        if (pos <= 0 || pos - 1 >= models.size) { setStatus("اختار موديل AI باش تمسحو"); return }
        val f = models[pos - 1]
        AlertDialog.Builder(this)
            .setTitle("نمسح ${f.name}؟")
            .setPositiveButton("إي") { _, _ ->
                f.delete()
                prefs.edit().putInt("engine_idx", 0).apply()
                refreshEngines(null)
                setStatus("تمسح الموديل")
            }
            .setNegativeButton("لا", null)
            .show()
    }

    private fun queryName(uri: Uri): String? {
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) return c.getString(i)
        }
        return null
    }

    private fun importModel(uri: Uri) {
        val name = queryName(uri) ?: "model_${System.currentTimeMillis()}.onnx"
        if (!name.endsWith(".onnx", true)) { setStatus("الملف لازم يكون .onnx"); return }
        setStatus("نزيدو $name ...")
        thread {
            val dest = File(modelsDir(), name)
            try {
                var total = 0L
                val ins = contentResolver.openInputStream(uri) ?: throw Exception("ما نجمتش نقرا الملف")
                ins.use { input ->
                    dest.outputStream().use { outs ->
                        val buf = ByteArray(1 shl 16)
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            outs.write(buf, 0, n)
                            total += n
                            if (total > MAX_MODEL_BYTES) throw Exception("الموديل أكبر من 1.5 جيجا")
                        }
                    }
                }
                runOnUiThread { refreshEngines(name); setStatus("تزاد الموديل: $name ✅") }
            } catch (e: Throwable) {
                dest.delete()
                setStatusAsync("خطأ: ${e.message}")
            }
        }
    }

    private fun downloadModel(url: String) {
        if (!url.startsWith("http")) { setStatus("الرابط غالط"); return }
        var name = url.substringAfterLast('/').substringBefore('?')
        if (name.isEmpty()) name = "model"
        if (!name.endsWith(".onnx", true)) name += ".onnx"
        setStatus("نحمّلو $name ...")
        thread {
            val dest = File(modelsDir(), name)
            try {
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 30000
                conn.readTimeout = 60000
                conn.instanceFollowRedirects = true
                conn.setRequestProperty("User-Agent", "Mozilla/5.0")
                val code = conn.responseCode
                if (code !in 200..299) {
                    conn.disconnect()
                    throw Exception("HTTP $code - الرابط ما يخدمش")
                }
                if (conn.contentLengthLong > MAX_MODEL_BYTES) {
                    conn.disconnect()
                    throw Exception("الموديل أكبر من 1.5 جيجا")
                }
                var total = 0L
                var shown = 0L
                conn.inputStream.use { input ->
                    dest.outputStream().use { outs ->
                        val buf = ByteArray(1 shl 16)
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            outs.write(buf, 0, n)
                            total += n
                            if (total > MAX_MODEL_BYTES) throw Exception("الموديل أكبر من 1.5 جيجا")
                            if (total - shown > 1_000_000) {
                                shown = total
                                setStatusAsync("نحمّلو $name: ${total / 1_000_000} MB")
                            }
                        }
                    }
                }
                conn.disconnect()
                runOnUiThread { refreshEngines(name); setStatus("تحمّل الموديل: $name ✅") }
            } catch (e: Throwable) {
                dest.delete()
                setStatusAsync("خطأ: ${e.message}")
            }
        }
    }

    // ---------- الصور ----------

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        if (requestCode == PICK_CODE) {
            val bmp = loadBitmap(uri)
            if (bmp == null) { setStatus("ما نجمتش نقرا الصورة"); return }
            inputBitmap = bmp
            preview.setImageBitmap(bmp)
            setStatus("الصورة جاهزة")
        } else if (requestCode == PICK_MODEL) {
            importModel(uri)
        }
    }

    private fun loadBitmap(uri: Uri, maxSide: Int = 1536): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > maxSide) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
    }

    private fun setStatus(s: String) { status.text = s }
    private fun setStatusAsync(s: String) { runOnUiThread { setStatus(s) } }

    private fun runAsync(work: () -> Bitmap) {
        runBtn.isEnabled = false
        saveBtn.isEnabled = false
        zoomBtn.isEnabled = false
        setStatus("نخدم... (ممكن ياخذ وقت)")
        thread {
            try {
                val bmp = work()
                runOnUiThread {
                    resultBitmap = bmp
                    preview.setImageBitmap(bmp)
                    saveBtn.isEnabled = true
                    zoomBtn.isEnabled = true
                    setStatus("خلصت ✅ (اضغط على الصورة للتكبير والمقارنة)")
                }
            } catch (e: OutOfMemoryError) {
                setStatusAsync("الذاكرة ما كفاتش. صغّر الحجم الأقصى (512).")
            } catch (e: Throwable) {
                setStatusAsync("خطأ: ${e.message}")
            } finally {
                runOnUiThread { runBtn.isEnabled = true }
            }
        }
    }

    private fun run() {
        val keys = Keys(
            cfIdBox.text.toString().trim(),
            cfTokenBox.text.toString().trim(),
            nvBox.text.toString().trim()
        )
        prefs.edit()
            .putString("cf_id", keys.cfId)
            .putString("cf_token", keys.cfToken)
            .putString("nv_key", keys.nvKey)
            .putInt("engine_idx", engineSpinner.selectedItemPosition)
            .putInt("size_idx", sizeSpinner.selectedItemPosition)
            .apply()

        val mode = modeGroup.checkedRadioButtonId
        val prompt = promptBox.text.toString().trim()
        val img = inputBitmap

        when (mode) {
            1 -> {
                if (prompt.isEmpty()) { setStatus("اكتب الفكرة (بالإنجليزية أحسن)"); return }
                lastOriginal = null
                runAsync { generateChain(prompt, keys) }
            }
            2 -> {
                if (img == null) { setStatus("اختار تصويرة أولا"); return }
                lastOriginal = img
                val pos = engineSpinner.selectedItemPosition
                if (pos <= 0) {
                    runAsync { Enhancer.enhance(img) }
                } else {
                    val models = listModels()
                    if (pos - 1 >= models.size) { setStatus("اختار محرك"); return }
                    val f = models[pos - 1]
                    val side = SIZES[sizeSpinner.selectedItemPosition.coerceIn(0, SIZES.size - 1)]
                    runAsync { OnnxUpscaler.run(f, img, side) { msg -> setStatusAsync(msg) } }
                }
            }
            else -> {
                if (img == null) { setStatus("اختار تصويرة أولا"); return }
                if (prompt.isEmpty()) { setStatus("اكتب شنو تحب تولي عليه الصورة"); return }
                lastOriginal = img
                runAsync { callHorde(prompt, img, 0.55) }
            }
        }
    }

    // ---------- عارض التكبير ----------

    private fun openViewer() {
        val res = resultBitmap ?: inputBitmap ?: return
        val orig = lastOriginal
        val dlg = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        val frame = FrameLayout(this)
        val zv = ZoomImageView(this)
        zv.showBitmap(res)
        frame.addView(zv, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        if (orig != null && resultBitmap != null) {
            var showingOrig = false
            var origScaled: Bitmap? = null
            val btn = Button(this)
            btn.text = "عرض الأصلية"
            btn.setOnClickListener {
                showingOrig = !showingOrig
                if (showingOrig) {
                    if (origScaled == null) {
                        origScaled = Bitmap.createScaledBitmap(orig, res.width, res.height, true)
                    }
                    zv.swapBitmap(origScaled!!)
                    btn.text = "عرض النتيجة"
                } else {
                    zv.swapBitmap(res)
                    btn.text = "عرض الأصلية"
                }
            }
            val lp = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
            lp.bottomMargin = dp(48)
            frame.addView(btn, lp)
        }
        dlg.setContentView(frame)
        dlg.show()
    }

    // ---------- شبكة ----------

    private fun http(
        method: String, url: String, headers: Map<String, String>,
        body: ByteArray?, readTimeout: Int = 120000
    ): HttpResult {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = method
            conn.connectTimeout = 30000
            conn.readTimeout = readTimeout
            for ((k, v) in headers) conn.setRequestProperty(k, v)
            if (body != null) {
                conn.doOutput = true
                conn.outputStream.use { it.write(body) }
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val bytes = stream?.use { it.readBytes() } ?: ByteArray(0)
            return HttpResult(code, bytes)
        } finally {
            conn.disconnect()
        }
    }

    private fun decodeBitmap(bytes: ByteArray): Bitmap =
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: throw Exception("الرد مش صورة")

    private fun findBase64(o: Any?): String? {
        when (o) {
            is JSONObject -> for (k in o.keys()) {
                val r = findBase64(o.opt(k))
                if (r != null) return r
            }
            is JSONArray -> for (i in 0 until o.length()) {
                val r = findBase64(o.opt(i))
                if (r != null) return r
            }
            is String -> if (o.length > 1000 && !o.startsWith("http")) return o
        }
        return null
    }

    private fun imageFromResponse(bytes: ByteArray): Bitmap {
        if (bytes.size > 4 &&
            (bytes[0] == 0x89.toByte() ||
                (bytes[0] == 0xFF.toByte() && bytes[1] == 0xD8.toByte()) ||
                bytes[0] == 'R'.code.toByte())
        ) return decodeBitmap(bytes)
        val text = String(bytes, Charsets.UTF_8)
        val b64 = findBase64(JSONObject(text))
            ?: throw Exception("ما لقيتش صورة في الرد: ${text.take(150)}")
        return decodeBitmap(Base64.decode(b64, Base64.DEFAULT))
    }

    // ---------- السيرفرات المجانية ----------

    private fun generateChain(prompt: String, k: Keys): Bitmap {
        val providers = ArrayList<Pair<String, () -> Bitmap>>()
        if (k.cfId.isNotEmpty() && k.cfToken.isNotEmpty())
            providers.add(Pair("Cloudflare", { callCloudflare(prompt, k) }))
        if (k.nvKey.isNotEmpty())
            providers.add(Pair("NVIDIA", { callNvidia(prompt, k) }))
        providers.add(Pair("Pollinations", { callPollinations(prompt) }))
        providers.add(Pair("AI Horde", { callHorde(prompt, null, 0.0) }))

        val errors = StringBuilder()
        for (pass in 1..3) {
            errors.setLength(0)
            for ((name, fn) in providers) {
                setStatusAsync("نجرّب $name... (دورة $pass/3)")
                try {
                    return fn()
                } catch (e: Exception) {
                    errors.append("$name: ${e.message?.take(120)}\n")
                }
            }
            if (pass < 3) {
                for (s in 20 downTo 1) {
                    setStatusAsync("كل السيرفرات مشغولة. نعاود بعد $s ثانية (دورة ${pass + 1}/3)")
                    Thread.sleep(1000)
                }
            }
        }
        throw Exception("كل السيرفرات فشلت:\n$errors")
    }

    private fun callCloudflare(prompt: String, k: Keys): Bitmap {
        val body = JSONObject().put("prompt", prompt).put("steps", 4).toString().toByteArray()
        val url = "https://api.cloudflare.com/client/v4/accounts/${k.cfId}/ai/run/@cf/black-forest-labs/flux-1-schnell"
        val r = http("POST", url,
            mapOf("Authorization" to "Bearer ${k.cfToken}", "Content-Type" to "application/json"), body)
        if (r.code !in 200..299) throw Exception("HTTP ${r.code}: ${String(r.bytes).take(150)}")
        return imageFromResponse(r.bytes)
    }

    private fun callNvidia(prompt: String, k: Keys): Bitmap {
        val body = JSONObject()
            .put("prompt", prompt).put("width", 1024).put("height", 1024)
            .put("seed", 0).put("steps", 4)
            .toString().toByteArray()
        val r = http("POST", "https://ai.api.nvidia.com/v1/genai/black-forest-labs/flux.1-schnell",
            mapOf(
                "Authorization" to "Bearer ${k.nvKey}",
                "Accept" to "application/json",
                "Content-Type" to "application/json"
            ), body)
        if (r.code !in 200..299) throw Exception("HTTP ${r.code}: ${String(r.bytes).take(150)}")
        return imageFromResponse(r.bytes)
    }

    private fun callPollinations(prompt: String): Bitmap {
        val enc = URLEncoder.encode(prompt, "UTF-8").replace("+", "%20")
        val seed = System.currentTimeMillis() % 100000
        val url = "https://image.pollinations.ai/prompt/$enc?width=1024&height=1024&model=flux&nologo=true&seed=$seed"
        for (attempt in 1..3) {
            val r = http("GET", url, mapOf("User-Agent" to "Mozilla/5.0"), null, 180000)
            if (r.code in 200..299) return imageFromResponse(r.bytes)
            if (r.code == 429 && attempt < 3) {
                for (s in 16 downTo 1) {
                    setStatusAsync("Pollinations مشغول. نعاود بعد $s ثانية")
                    Thread.sleep(1000)
                }
                continue
            }
            throw Exception("HTTP ${r.code}")
        }
        throw Exception("Pollinations مشغول")
    }

    private fun roundTo64(v: Float): Int = ((v / 64f).roundToInt().coerceAtLeast(1)) * 64

    private fun callHorde(prompt: String, src: Bitmap?, strength: Double): Bitmap {
        val base = "https://aihorde.net/api/v2/generate"
        val headers = mapOf(
            "apikey" to "0000000000",
            "Content-Type" to "application/json",
            "Client-Agent" to "aiimage:1.0:unknown"
        )
        var w = 512
        var h = 512
        var srcB64: String? = null
        if (src != null) {
            val scale = 512f / maxOf(src.width, src.height)
            w = roundTo64(src.width * scale)
            h = roundTo64(src.height * scale)
            val scaled = Bitmap.createScaledBitmap(src, w, h, true)
            val bos = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, 90, bos)
            srcB64 = Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
        }
        val params = JSONObject().put("width", w).put("height", h).put("steps", 25).put("n", 1)
        if (srcB64 != null) params.put("denoising_strength", strength)
        val req = JSONObject()
            .put("prompt", prompt).put("params", params)
            .put("nsfw", false).put("censor_nsfw", true).put("r2", true)
        if (srcB64 != null) req.put("source_image", srcB64).put("source_processing", "img2img")

        val sub = http("POST", "$base/async", headers, req.toString().toByteArray())
        if (sub.code !in 200..299) throw Exception("Horde HTTP ${sub.code}: ${String(sub.bytes).take(200)}")
        val id = JSONObject(String(sub.bytes)).getString("id")

        val start = System.currentTimeMillis()
        while (System.currentTimeMillis() - start < 20 * 60 * 1000) {
            Thread.sleep(5000)
            val c = http("GET", "$base/check/$id", headers, null)
            if (c.code !in 200..299) continue
            val j = JSONObject(String(c.bytes))
            if (j.optBoolean("faulted")) throw Exception("Horde: فشل الطلب")
            if (j.optBoolean("done")) {
                val st = http("GET", "$base/status/$id", headers, null)
                val gens = JSONObject(String(st.bytes)).getJSONArray("generations")
                if (gens.length() == 0) throw Exception("Horde: ما رجّعش صورة (يمكن الفلتر)")
                val img = gens.getJSONObject(0).getString("img")
                if (img.startsWith("http")) {
                    val d = http("GET", img, emptyMap(), null)
                    return imageFromResponse(d.bytes)
                }
                return imageFromResponse(Base64.decode(img, Base64.DEFAULT))
            }
            setStatusAsync(
                "AI Horde: في الطابور. الترتيب ${j.optInt("queue_position")} - الوقت المتوقع ${j.optInt("wait_time")} ثانية"
            )
        }
        http("DELETE", "$base/status/$id", headers, null)
        throw Exception("AI Horde: انتهى الوقت")
    }

    private fun save() {
        val bmp = resultBitmap ?: return
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "ai_${System.currentTimeMillis()}.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AIImage")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri == null) { setStatus("ما نجمتش نحفظ"); return }
        setStatus("نحفظو...")
        thread {
            try {
                contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                setStatusAsync("تحفظت في المعرض (Pictures/AIImage)")
            } catch (e: Throwable) {
                setStatusAsync("خطأ في الحفظ: ${e.message}")
            }
        }
    }
}

// ---------- عارض بتكبير بالأصبعين ----------

class ZoomImageView(ctx: Context) : ImageView(ctx) {
    private val m = Matrix()
    private val v = FloatArray(9)
    private var minScale = 1f

    private val scaleDetector = ScaleGestureDetector(ctx,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                zoomBy(d.scaleFactor, d.focusX, d.focusY)
                return true
            }
        })

    private val gestures = GestureDetector(ctx,
        object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (currentScale() > minScale * 1.5f) fit() else zoomBy(4f, e.x, e.y)
                return true
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                m.postTranslate(-dx, -dy)
                fixTranslation()
                imageMatrix = m
                return true
            }
        })

    init { scaleType = ScaleType.MATRIX }

    fun showBitmap(b: Bitmap) {
        setImageBitmap(b)
        post { fit() }
    }

    fun swapBitmap(b: Bitmap) {
        setImageBitmap(b)
    }

    private fun currentScale(): Float {
        m.getValues(v)
        return v[Matrix.MSCALE_X]
    }

    private fun fit() {
        val d = drawable ?: return
        val vw = width.toFloat()
        val vh = height.toFloat()
        val dw = d.intrinsicWidth.toFloat()
        val dh = d.intrinsicHeight.toFloat()
        if (vw <= 0f || vh <= 0f || dw <= 0f || dh <= 0f) return
        val s = minOf(vw / dw, vh / dh)
        m.reset()
        m.postScale(s, s)
        m.postTranslate((vw - dw * s) / 2f, (vh - dh * s) / 2f)
        minScale = s
        imageMatrix = m
    }

    private fun zoomBy(f: Float, px: Float, py: Float) {
        val cur = currentScale()
        if (cur <= 0f) return
        val target = (cur * f).coerceIn(minScale, minScale * 16f)
        val real = target / cur
        m.postScale(real, real, px, py)
        fixTranslation()
        imageMatrix = m
    }

    private fun fixTranslation() {
        val d = drawable ?: return
        m.getValues(v)
        val s = v[Matrix.MSCALE_X]
        val iw = d.intrinsicWidth * s
        val ih = d.intrinsicHeight * s
        val vw = width.toFloat()
        val vh = height.toFloat()
        var tx = v[Matrix.MTRANS_X]
        var ty = v[Matrix.MTRANS_Y]
        tx = if (iw <= vw) (vw - iw) / 2f else tx.coerceIn(vw - iw, 0f)
        ty = if (ih <= vh) (vh - ih) / 2f else ty.coerceIn(vh - ih, 0f)
        v[Matrix.MTRANS_X] = tx
        v[Matrix.MTRANS_Y] = ty
        m.setValues(v)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (drawable != null) fit()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(e)
        if (!scaleDetector.isInProgress) gestures.onTouchEvent(e)
        return true
    }
}

// ---------- محرك AI محلي (ONNX) ----------

object OnnxUpscaler {
    @Volatile
    var cancel = false

    fun run(modelFile: File, srcIn: Bitmap, maxSide: Int, progress: (String) -> Unit): Bitmap {
        cancel = false
        var src = srcIn
        val longest = maxOf(src.width, src.height)
        if (longest > maxSide) {
            val f = maxSide.toFloat() / longest
            src = Bitmap.createScaledBitmap(
                src,
                (src.width * f).roundToInt().coerceAtLeast(1),
                (src.height * f).roundToInt().coerceAtLeast(1),
                true
            )
        }
        val w = src.width
        val h = src.height
        val srcPx = IntArray(w * h)
        src.getPixels(srcPx, 0, w, 0, 0, w, h)

        val env = OrtEnvironment.getEnvironment()
        val opts = OrtSession.SessionOptions()
        opts.setIntraOpNumThreads(4)
        val session = env.createSession(modelFile.absolutePath, opts)
        try {
            val inName = session.inputNames.iterator().next()
            val tinfo = session.inputInfo[inName]!!.info as TensorInfo
            if (tinfo.type != OnnxJavaType.FLOAT) {
                throw Exception("الموديل هذا مش float32. استعمل نسخة fp32.")
            }
            val shape = tinfo.shape
            if (shape.size != 4) throw Exception("شكل المدخل مش مدعوم (لازم 1x3xHxW)")
            val th = if (shape[2] > 0) shape[2].toInt() else 128
            val tw = if (shape[3] > 0) shape[3].toInt() else 128
            val pad = if (minOf(th, tw) >= 64) 10 else 0
            val coreW = tw - 2 * pad
            val coreH = th - 2 * pad
            val cols = (w + coreW - 1) / coreW
            val rows = (h + coreH - 1) / coreH
            val total = cols * rows

            val inBuf = ByteBuffer.allocateDirect(4 * 3 * th * tw)
                .order(ByteOrder.nativeOrder()).asFloatBuffer()
            val plane = tw * th

            var outBmp: Bitmap? = null
            var scale = 0
            var mul = 255f
            var done = 0
            val t0 = System.currentTimeMillis()

            for (ry in 0 until rows) {
                for (rx in 0 until cols) {
                    if (cancel) throw Exception("تلغات المعالجة")
                    val cx = rx * coreW
                    val cy = ry * coreH
                    val cw = minOf(coreW, w - cx)
                    val ch = minOf(coreH, h - cy)

                    for (y in 0 until th) {
                        val sy = (cy - pad + y).coerceIn(0, h - 1)
                        for (x in 0 until tw) {
                            val sx = (cx - pad + x).coerceIn(0, w - 1)
                            val p = srcPx[sy * w + sx]
                            val i = y * tw + x
                            inBuf.put(i, ((p shr 16) and 255) / 255f)
                            inBuf.put(plane + i, ((p shr 8) and 255) / 255f)
                            inBuf.put(2 * plane + i, (p and 255) / 255f)
                        }
                    }
                    inBuf.rewind()

                    val tensor = OnnxTensor.createTensor(
                        env, inBuf, longArrayOf(1, 3, th.toLong(), tw.toLong()))
                    val result = session.run(mapOf(inName to tensor))
                    try {
                        val ot = result.get(0) as OnnxTensor
                        val osh = ot.info.shape
                        val oh = osh[2].toInt()
                        val ow = osh[3].toInt()
                        val fb = ot.floatBuffer

                        if (scale == 0) {
                            scale = oh / th
                            if (scale < 1) throw Exception("المخرج أصغر من المدخل؟")
                            if (w.toLong() * scale * h * scale > 36_000_000L) {
                                throw Exception("النتيجة كبيرة برشا. صغّر الحجم الأقصى.")
                            }
                            var mx = 0f
                            for (k in 0 until fb.capacity()) mx = max(mx, fb.get(k))
                            mul = if (mx > 4f) 1f else 255f
                            outBmp = Bitmap.createBitmap(w * scale, h * scale, Bitmap.Config.ARGB_8888)
                        }

                        val ocw = cw * scale
                        val och = ch * scale
                        val ox0 = pad * scale
                        val oy0 = pad * scale
                        val oplane = oh * ow
                        val px = IntArray(ocw * och)
                        for (y in 0 until och) {
                            val rowBase = (oy0 + y) * ow + ox0
                            for (x in 0 until ocw) {
                                val i = rowBase + x
                                val r = (fb.get(i) * mul + 0.5f).toInt().coerceIn(0, 255)
                                val g = (fb.get(oplane + i) * mul + 0.5f).toInt().coerceIn(0, 255)
                                val b = (fb.get(2 * oplane + i) * mul + 0.5f).toInt().coerceIn(0, 255)
                                px[y * ocw + x] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                            }
                        }
                        outBmp!!.setPixels(px, 0, ocw, cx * scale, cy * scale, ocw, och)
                    } finally {
                        result.close()
                        tensor.close()
                    }

                    done++
                    val elapsed = System.currentTimeMillis() - t0
                    val remainMin = (elapsed.toDouble() / done * (total - done) / 60000.0).roundToInt()
                    progress("معالجة بالـ AI: $done/$total - باقي حوالي $remainMin دقيقة")
                }
            }
            return outBmp ?: throw Exception("ما تعمل حتى جزء")
        } finally {
            session.close()
        }
    }
}

object Enhancer {

    fun enhance(src: Bitmap): Bitmap {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        autoLevels(px)
        saturate(px, 1.12f)
        val out = unsharp(px, w, h, 2, 0.7f)
        return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
    }

    private fun autoLevels(px: IntArray) {
        val hist = IntArray(256)
        for (p in px) {
            val l = (0.299 * ((p shr 16) and 255) + 0.587 * ((p shr 8) and 255) + 0.114 * (p and 255)).toInt()
            hist[l]++
        }
        val clip = px.size / 100
        var acc = 0
        var lo = 0
        while (lo < 255 && acc + hist[lo] <= clip) { acc += hist[lo]; lo++ }
        acc = 0
        var hi = 255
        while (hi > 0 && acc + hist[hi] <= clip) { acc += hist[hi]; hi-- }
        if (hi - lo < 50) return
        val scale = 255f / (hi - lo)
        var sum = 0L
        for (i in 0..255) sum += i.toLong() * hist[i]
        val mean = sum.toFloat() / px.size
        val gamma = if (mean < 110f) 0.85 else 1.0
        val lut = IntArray(256) { v ->
            val x = ((v - lo) * scale).coerceIn(0f, 255f) / 255f
            val y = Math.pow(x.toDouble(), gamma).toFloat()
            (y * 255f + 0.5f).toInt().coerceIn(0, 255)
        }
        for (i in px.indices) {
            val p = px[i]
            val r = lut[(p shr 16) and 255]
            val g = lut[(p shr 8) and 255]
            val b = lut[p and 255]
            px[i] = (p and (0xFF shl 24)) or (r shl 16) or (g shl 8) or b
        }
    }

    private fun saturate(px: IntArray, s: Float) {
        for (i in px.indices) {
            val p = px[i]
            val r = (p shr 16) and 255
            val g = (p shr 8) and 255
            val b = p and 255
            val l = 0.299f * r + 0.587f * g + 0.114f * b
            val nr = (l + (r - l) * s).toInt().coerceIn(0, 255)
            val ng = (l + (g - l) * s).toInt().coerceIn(0, 255)
            val nb = (l + (b - l) * s).toInt().coerceIn(0, 255)
            px[i] = (p and (0xFF shl 24)) or (nr shl 16) or (ng shl 8) or nb
        }
    }

    private fun unsharp(px: IntArray, w: Int, h: Int, radius: Int, amount: Float): IntArray {
        val out = IntArray(px.size) { 0xFF shl 24 }
        val chan = IntArray(px.size)
        val tmp = IntArray(px.size)
        val blur = IntArray(px.size)
        for (c in 0..2) {
            val shift = 16 - 8 * c
            for (i in px.indices) chan[i] = (px[i] shr shift) and 255
            boxBlur(chan, tmp, blur, w, h, radius)
            for (i in px.indices) {
                val o = chan[i]
                val diff = o - blur[i]
                val v = if (abs(diff) < 3) o else (o + amount * diff).toInt().coerceIn(0, 255)
                out[i] = out[i] or (v shl shift)
            }
        }
        return out
    }

    private fun boxBlur(src: IntArray, tmp: IntArray, dst: IntArray, w: Int, h: Int, r: Int) {
        val d = 2 * r + 1
        for (y in 0 until h) {
            val row = y * w
            var sum = 0
            for (x in -r..r) sum += src[row + x.coerceIn(0, w - 1)]
            for (x in 0 until w) {
                tmp[row + x] = sum / d
                val add = (x + r + 1).coerceAtMost(w - 1)
                val rem = (x - r).coerceAtLeast(0)
                sum += src[row + add] - src[row + rem]
            }
        }
        for (x in 0 until w) {
            var sum = 0
            for (y in -r..r) sum += tmp[y.coerceIn(0, h - 1) * w + x]
            for (y in 0 until h) {
                dst[y * w + x] = sum / d
                val add = (y + r + 1).coerceAtMost(h - 1)
                val rem = (y - r).coerceAtLeast(0)
                sum += tmp[add * w + x] - tmp[rem * w + x]
            }
        }
    }
}
